package com.test.am;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import org.apache.axiom.om.impl.llom.OMTextImpl;
import org.apache.synapse.MessageContext;
import org.apache.synapse.config.Entry;
import org.apache.synapse.mediators.AbstractMediator;
import org.apache.synapse.registry.Registry;

import java.io.InputStreamReader;

/**
 * Created by delegate on 5/29/17.
 */
public class CustomeHandler1 extends AbstractMediator {

    @Override
    public boolean mediate(MessageContext messageContext) {
        try {
            System.out.println("In custom handler " + messageContext);
            Registry registry = messageContext.getConfiguration().getRegistry();
            OMTextImpl resource = (OMTextImpl) registry.getResource(new Entry("conf:/jsonschema/test_schema_1.json"), null);
            String jsonPayload = (String) messageContext.getProperty("JSONPayload");
            System.out.println(jsonPayload);

            JsonNode jsonNodeSchema = JsonLoader.fromReader(new InputStreamReader(resource.getInputStream()));
            JsonNode jsonNodeContent = JsonLoader.fromString(jsonPayload);

            final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
            final JsonSchema schema = factory.getJsonSchema(jsonNodeSchema);

            ProcessingReport processingReport = schema.validate(jsonNodeContent);
            processingReport.forEach(action -> System.out.println(action.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }
}
