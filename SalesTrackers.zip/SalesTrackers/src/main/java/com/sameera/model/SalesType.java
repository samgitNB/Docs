package com.sameera.model;

public class SalesType {

	private String salesType;

	public String getSalesType() {
		return salesType;
	}

	public void setSalesType(String salesType) {
		this.salesType = salesType;
	}
}
