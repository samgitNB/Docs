package com.sameera.model;

import org.hibernate.validator.constraints.Range;

public class Sales {

	@Range(min =100 , max=10000)
	private int sales;
	private String salesType;
	

	public String getSalesType() {
		return salesType;
	}

	public void setSalesType(String salesType) {
		this.salesType = salesType;
	}

	public int getSales() {
		return sales;
	}

	public void setSales(int sales) {
		this.sales = sales;
	}
}
