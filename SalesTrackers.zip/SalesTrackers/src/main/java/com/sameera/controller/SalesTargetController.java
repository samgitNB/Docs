package com.sameera.controller;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.sameera.model.Sales;
import com.sameera.model.SalesType;
import com.sameera.service.SaleService;

@Controller
@SessionAttributes("addTarget")
public class SalesTargetController {

	@Autowired
	private SaleService salesService;
	
	@RequestMapping(value = "/addTarget", method = RequestMethod.GET)
	public String addSalesTarget(Model model) {

		Sales sales = new Sales();

		sales.setSales(81000);
		model.addAttribute("addTarget", sales);
		return "addSalesValue";
	}

	@RequestMapping(value = "/addTarget", method = RequestMethod.POST)
	public String updateSalesTarget(@Valid @ModelAttribute("addTarget") Sales sales, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			System.out.println("Error State is :" + bindingResult.hasErrors());
			return "addSalesValue";
		} else {

			System.out.println("Target update : " + sales.getSales());
			return "addSalesValue";
		}

	}
	
	
//=====================================================================================
	
	@RequestMapping(value = "/addTarget")
	public String addSales(@ModelAttribute("addTarget") SalesType salesType) {
		System.out.println("Sales is :" + salesType.getSalesType());
		return "addSalesValue";

	}
	
	@RequestMapping(value = "/salesType",method=RequestMethod.GET)
	public @ResponseBody List<SalesType> getAllSalesType() {

		System.out.println("saleType......................");
		return salesService.getAllSalesType();

	}

}
