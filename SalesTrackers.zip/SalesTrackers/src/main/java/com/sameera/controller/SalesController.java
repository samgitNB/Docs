package com.sameera.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sameera.model.Sales;

@Controller
public class SalesController {

	@RequestMapping(value = "/greeting")
	public String version(Model model) {
		
		model.addAttribute("greeting", "Hello Spring MVC");
		return "index";
	}
	
	@RequestMapping(value="addSales")
	public String addSales(@ModelAttribute("salesValues") Sales sales){
		
		System.out.println("Sales is :"+sales.getSales());
		//mode.addAttribute("salesValue", "Enter Sales Totals : " + sales);
		return "addSalesValue";
		//return "forward:addBounceSales";
	}
	
	/*@RequestMapping(value="addBounceSales")
	public String addBounceSales(Model mode , @RequestParam(value="sales",required=false,defaultValue = "0") String sales){
		
		System.out.println("Sales is :"+sales);
		mode.addAttribute("salesValue", "Enter Sales Totals : " + sales);
		return "addSalesValue";
	}*/
}
