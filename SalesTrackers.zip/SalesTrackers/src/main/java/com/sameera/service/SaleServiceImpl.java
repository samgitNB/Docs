package com.sameera.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import com.sameera.model.SalesType;

@Service("saleService")
public class SaleServiceImpl implements SaleService {

	public List<SalesType> getAllSalesType() {
		
		List<SalesType> saleType = new ArrayList<SalesType>();

		SalesType direct = new SalesType();
		SalesType web = new SalesType();
		SalesType shop = new SalesType();
		SalesType buy = new SalesType();

		direct.setSalesType("Direct");
		saleType.add(direct);

		web.setSalesType("Web");
		saleType.add(web);

		shop.setSalesType("Cards");
		saleType.add(shop);
		
		buy.setSalesType("Buy");
		saleType.add(buy);

		return saleType;
	}

}
