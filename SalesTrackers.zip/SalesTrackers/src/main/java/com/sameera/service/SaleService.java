package com.sameera.service;

import java.util.List;

import com.sameera.model.SalesType;

public interface SaleService {

	public  List<SalesType> getAllSalesType();

}