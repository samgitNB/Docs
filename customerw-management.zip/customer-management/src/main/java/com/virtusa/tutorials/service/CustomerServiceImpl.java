package com.virtusa.tutorials.service;

import com.virtusa.tutorials.model.Customer;
import com.virtusa.tutorials.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public Iterable<Customer> findAllCustomers() {
        return customerRepository.findAllCustomers();
    }

    @Override
    public Customer findByName(String name) {
        return null;
    }

    @Override
    public Customer findById(int id) {
        return null;
    }

    @Override
    public boolean save(Customer customer) {


        boolean saveStatus = false;

        if (customer != null && saveStatus == false) {
            saveStatus = customerRepository.save(customer);
        } else {
            saveStatus = false;
        }
        return saveStatus;
    }

    @Override
    public boolean update(Customer customer) {
        boolean isUpdate =false;
        if(customer.getId()){
            isUpdate = customerRepository.update(customer);
        }else {
            isUpdate =false;
        }

        return isUpdate;

    }

    @Override
    public void deleteById(int id) {
        if(id != null){
            customerRepository.deleteById(id);
        }

    }
}