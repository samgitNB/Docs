package com.virtusa.tutorials.repository;

import com.virtusa.tutorials.model.Customer;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;


@Repository
public class CustomerRepositoryImpl implements CustomerRepository{


    private static Map<Integer,Customer> db = new HashMap<>();
    static {

        Customer customer = new Customer();
        customer.setId(1);
        customer.setName("Jone");
        customer.setCountry("USA");
        customer.setMobile("075-555888");

        db.put(1, customer);

    }

    @Override
    public Iterable<Customer> findAllCustomers() {
        return db.values();
    }

    @Override
    public Customer findByName(String name) {
        return null;
    }

    @Override
    public boolean save(Customer customer) {

        db.put(customer.getId(),customer);
        return true;
    }

    @Override
    public boolean update(Customer customer) {

        db.put(customer.getId(), customer);
        return true;
    }

    @Override
    public void deleteById(int id) {

        db.remove(id);

    }
}
