package com.virtusa.tutorials.controller;

import com.virtusa.tutorials.model.Customer;
import com.virtusa.tutorials.service.CustomerService;
import com.virtusa.tutorials.utils.CustomeMassages;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    /*
    *produces = { "application/xml", "text/xml" }
    * */
    @RequestMapping(value = "/create", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> createCustomer(@RequestBody Customer customer) {

        ResponseEntity<?> response;

        if (customerService.save(customer)) {
            response = new ResponseEntity<CustomeMassages>(new CustomeMassages("Save"), HttpStatus.CREATED);
            System.out.println(response.getStatusCode() + " | " + response.getHeaders());

        } else {
            response = new ResponseEntity<CustomeMassages>(new CustomeMassages("error duplicate names"), HttpStatus.CONFLICT);
            System.out.println(response.getStatusCode() + " | " + response.getHeaders());
        }


        return response;
    }


   /*
   * ====================== Retrieve All Customers ================================
   * */

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public Iterable<Customer> listAllCustomers() {

        return customerService.findAllCustomers();
    }


   /*
   * ====================== Retrieve Single Customer ================================
   * */

    @RequestMapping(value = "/view/{id}", method = RequestMethod.GET)
    public Customer getCustomer(@PathVariable("id") int id) {

        return customerService.findById(id);

    }

    /*
    * -------------------Update Customer------------------------------------------
    * */

    @RequestMapping(value = "/update/{id}", method = RequestMethod.PUT)
    public updateCustomer(@PathVariable("id") int id, @RequestBody Customer customer) {

        Customer cus = new Customer();
        cus.setId(id);
        customerService.update(customer);

    }

    /*
    *-------------------Delete Customer------------------------------------------
     */

    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
    public void deleteCustomer(@PathVariable("id") int id) {

        customerService.deleteById(id);
    }


}
