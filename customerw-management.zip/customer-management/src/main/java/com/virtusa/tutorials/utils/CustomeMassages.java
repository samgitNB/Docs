package com.virtusa.tutorials.utils;

public class CustomeMassages {

    private String respondMsg;


    public CustomeMassages(String respondMsg) {
        this.respondMsg = respondMsg;
    }
}
