package com.virtusa.tutorials.service;

import com.virtusa.tutorials.model.Customer;

public interface CustomerService {

    Iterable<Customer> findAllCustomers();
    Customer findByName(String name);
    Customer findById(int id);
    boolean save(Customer customer);
    boolean update(Customer customer);
    void deleteById(int id);
}
