package com.virtusa.tutorials.repository;

import com.virtusa.tutorials.model.Customer;

import java.util.List;

public interface CustomerRepository {

    Iterable<Customer> findAllCustomers();
    Customer findByName(String name);
    boolean save(Customer customer);
    boolean update(Customer customer);
    void deleteById(int id);
}
