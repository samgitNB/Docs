import { NgbDateStruct } from './ngb-date-struct';
export declare class NgbDatepickerDayView {
    currentMonth: number;
    date: NgbDateStruct;
    disabled: boolean;
    focused: boolean;
    selected: boolean;
    isMuted(): boolean;
}
