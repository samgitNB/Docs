import { ModuleWithProviders } from '@angular/core';
export { NgbPagination } from './pagination';
export { NgbPaginationConfig } from './pagination-config';
export declare class NgbPaginationModule {
    static forRoot(): ModuleWithProviders;
}
