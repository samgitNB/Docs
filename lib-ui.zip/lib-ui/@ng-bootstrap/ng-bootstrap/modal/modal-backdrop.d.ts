export declare class NgbModalBackdrop {
}
