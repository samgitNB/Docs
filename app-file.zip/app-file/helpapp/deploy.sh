#!/usr/bin/env bash

DEPLOY_PROJECT_ID=$(curl --header "PRIVATE-TOKEN: ${API_TOKEN}" "${BASE_URL}"/api/v3/projects/"$7" | jq '.id')
echo DEPLOY_PROJECT_ID is ${DEPLOY_PROJECT_ID} for $7

# get commit statuses
commit=$(curl -s --header "PRIVATE-TOKEN: $1" $2/api/v3/projects/$3/repository/commits/$4/statuses)
echo $commit

# get build number
TRIGGER_BUILD_ID=$(echo $commit | jq '.[] | select(.name=="build_app") | .id')
echo $TRIGGER_BUILD_ID

# trigger deployment
curl --request POST --form token=$5 --form ref=$6 --form "variables[TRIGGER_BUILD]=${TRIGGER_BUILD_ID}" $2/api/v3/projects/${DEPLOY_PROJECT_ID}/trigger/builds

