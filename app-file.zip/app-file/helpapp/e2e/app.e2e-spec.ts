import { VcuxConsumerPage } from './app.po';

describe('vcux-consumer App', () => {
  let page: VcuxConsumerPage;

  beforeEach(() => {
    page = new VcuxConsumerPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
