import {Http, RequestOptionsArgs, Headers} from '@angular/http';
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import {GlobalsService, HttpService, IGridXhrParams} from 'vc-ux';


@Injectable()
export class GridService {

  constructor(private http: Http, private httpService: HttpService, private globalsService: GlobalsService) {}

  public getVulnerabilityData(params: IGridXhrParams) {
    return this.http
      .get('./testdata/grid-example.data.json')
      .map(res => res.json());
  }

  public getFindingsData(params: IGridXhrParams) {
    const addr = this.globalsService.uigateway + '/appsec/v1/applications/' +
      '00000000-0000-4000-0000-000000000001/findings';

    return this.httpService
      .getByFullPath(addr)
      .map(res => res.json());
  }

  public getNavigation() {
    /**
     * const addr = this.globalsService.uigateway + '/api/navigation/navigations';
     * calling to mock service
     */

    const addr = './testdata/navigationService.json';
    return this.httpService
      .getByFullPath(addr)
      .map(res => res.json())
      .catch( e => {console.warn('HEY'); throw e; });
  }

}
