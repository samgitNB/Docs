import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {GlobalsModule, GlobalsService, UXPatternsModule} from 'vc-ux';
import { PartialLoaderModule } from 'vc-ux';
import {TranslateModule} from '@ngx-translate/core';
import {GridService} from './grid-example.service';

import { AppComponent } from './app.component';
import { ApplicationListModule } from './application-list/application-list.module';
import { ApplicationAddModule } from './application-add/application-add.module';
// poc modules
import { PocListModule } from './poc-list/poc-list.module';
import { PocAddModule } from './poc-add/poc-add.module';

import { routing } from './app.routes';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    UXPatternsModule,
    TranslateModule,
    PartialLoaderModule.forRoot({
      lang: 'en',
      prefix: '/assets/i18n',
      suffix: '.json',
    }),
    GlobalsModule,
    ApplicationListModule,
    ApplicationAddModule,
    PocListModule,
    PocAddModule,
    routing,
  ],
  providers: [
    GridService,
    GlobalsService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
