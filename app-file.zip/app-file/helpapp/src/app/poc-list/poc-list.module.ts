import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PocListComponent } from './components/poc-list/poc-list.component';
import {TranslateModule} from '@ngx-translate/core';
import {GlobalsModule, GlobalsService, UXPatternsModule} from 'vc-ux';

import { GridService} from '../services/grid-poc.service';
import { ModalExampleContentComponent } from './components/modal/modal-example-content.component';



@NgModule({
  imports: [
    CommonModule,
    UXPatternsModule,
    CommonModule,
    BrowserModule,
    FormsModule,
    HttpModule,
    UXPatternsModule,
    GlobalsModule,
  ],
  providers: [
    GridService,
    GlobalsService,
  ],
  declarations: [PocListComponent , ModalExampleContentComponent],
  exports: [PocListComponent],
  entryComponents: [ModalExampleContentComponent]
})
export class PocListModule { }
