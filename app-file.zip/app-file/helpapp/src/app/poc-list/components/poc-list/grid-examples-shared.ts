// import { ButtonActionType, ButtonType, ColGroupDefWithCustomHeader, IActionSelectionConfig } from 'vc-ux/lib';
// import { Component } from '@angular/core';
// import { Subscription } from 'rxjs/Subscription';
// import { ColDef } from 'ag-grid';
// export class GridExamplesShared {
//   /**
//    * Define unique ids for each action button. By subscribing to GridConfig#actionSelectionButtonClicked,
//    * the id will be passed in as a parameter. See the constructor.
//    * @returns {IActionSelectionConfig[]}
//    */
//   public static get actionConfig(): IActionSelectionConfig[] {
//     return [
//       {id: 'add_here', label: 'Add Here'},
//       {id: 'nothing', label: 'Nothing', vcButton: {type: ButtonType.Secondary}},
//       {id: 'download', label: 'Download', vcButton: {actionType: ButtonActionType.Download}},
//       // This won't show
//       {id: 'hidden', label: '', visible: false},
//     ];
//   }

//   public static get colAgentStatus(): ColDef {
//     return {headerName: 'Agent Status', field: 'status', unSortIcon: true};
//   }

//   public static get colCweId(): ColDef {
//     return {headerName: 'Cwe Id', field: 'cwe_id', unSortIcon: true};
//   }

//   // public static get colDateDiscovered(): ColDef {
//   //   return {
//   //     headerName: 'Date Discovered',
//   //     field: 'first_time_seen',
//   //     unSortIcon: true,
//   //     cellRendererFramework: DateCellRendererComponent,
//   //   };
//   // }

//   // public static get colDateLastSeen(): ColDef {
//   //   return {
//   //     headerName: 'Date Last Seen',
//   //     field: 'last_time_seen',
//   //     sort: 'desc',
//   //     unSortIcon: true,
//   //     cellRendererFramework: DateCellRendererComponent,
//   //   };
//   // }

//   public static get colSelect(): ColDef {
//     return {
//       headerName: '',
//       field: 'select',
//       maxWidth: 30,
//       headerCheckboxSelection: true, // true=checkbox in the header
//       checkboxSelection: true, // true=checkbox for each row
//       suppressSorting: true,
//     };
//   }

//   public static get colSeverity(): ColDef {
//     return {
//       headerName: 'Severity',
//       field: 'severity',
//       unSortIcon: true,
//       cellRendererFramework: SeverityCellRendererComponent,
//     };
//   }

//   public static get colTitle(): ColDef {
//     return {headerName: 'Title', field: 'title', suppressSorting: true};
//   }

//   public static get columnDefs(): ColDef[] {
//     return [
//       GridExamplesShared.colSelect,
//       GridExamplesShared.colTitle,
//       GridExamplesShared.colSeverity,
//       GridExamplesShared.colCweId,
//       GridExamplesShared.colDateDiscovered,
//       GridExamplesShared.colDateLastSeen,
//       GridExamplesShared.colAgentStatus,
//     ];
//   }

//   /**
//    * Use the standard column definition and then add headerComponentFramework.
//    * Optionally add refData if you want to override the default info button.
//    * @returns {ColGroupDefWithCustomHeader[]}
//    */
//   public static get columnDefsWithCustomHeader(): ColGroupDefWithCustomHeader[] {
//     const cweId: ColDef = GridExamplesShared.colCweId;
//     const dateLastSeen: ColDef = GridExamplesShared.colDateLastSeen;

//     cweId.headerComponentFramework = GridHeaderButtonComponent;
//     dateLastSeen.headerComponentFramework = GridHeaderButtonComponent;
//     dateLastSeen.refData = {[gridHeaderButtonType]: 'question'};

//     return [
//       {
//         headerName: '',
//         groupId: 'group 0',
//         children: [
//           GridExamplesShared.colSelect,
//           GridExamplesShared.colTitle,
//           GridExamplesShared.colSeverity,
//         ],
//       },
//       {
//         headerName: 'Now is the time to span multiple columns',
//         groupId: 'header-group-id',
//         headerGroupComponentFramework: GridHeaderGroupButtonComponent,
//         children: [
//           cweId,
//           GridExamplesShared.colDateDiscovered,
//         ],
//       },
//       {
//         headerName: '',
//         groupId: 'group 2',
//         children: [
//           dateLastSeen,
//           GridExamplesShared.colAgentStatus,
//         ],
//       },
//     ];
//   }

//   /**
//    * The title column is configured as a full row renderer
//    * @returns {ColDef[]}
//    */
//   public static get columnDefsWithExpandableRow(): ColDef[] {
//     const title: ColDef = GridExamplesShared.colTitle;

//     // These values are taken from an ag-grid example - I know not why
//     title.cellRenderer = 'group';
//     title.cellRendererParams = {suppressCount: true};

//     return [
//       title,
//       GridExamplesShared.colSeverity,
//       GridExamplesShared.colCweId,
//       GridExamplesShared.colDateDiscovered,
//       GridExamplesShared.colDateLastSeen,
//       GridExamplesShared.colAgentStatus,
//     ];
//   }

//   /**
//    * 1. The selection column turns off headerCheckboxSelection. Consequently, single row select
//    * will be configured.
//    * 2. Customizes the severity cell with a clickable button
//    * @returns {ColDef[]}
//    */
//   public static get columnDefsWithSingleRowSelectAndSeverityButton(): ColDef[] {
//     const select: ColDef = GridExamplesShared.colSelect;
//     const severity: ColDef = GridExamplesShared.colSeverity;

//     // This changes row select selection from 'multiple' to 'single'
//     select.headerCheckboxSelection = false;
//     // Customize severity cell with a clickable button
//     severity.cellRendererFramework = ButtonClickCellRendererComponent;

//     return [
//       select,
//       GridExamplesShared.colTitle,
//       severity,
//       GridExamplesShared.colCweId,
//       GridExamplesShared.colDateDiscovered,
//       GridExamplesShared.colDateLastSeen,
//       GridExamplesShared.colAgentStatus,
//     ];
//   }

//   public static get emptyConfig(): IEmptyConfig {
//     return {
//       noData: 'YOU do not have any data to display.',
//       noSearchData: 'YOUR search did not produce any results.  Change your search criteria and try again.',
//       noFilterData: 'YOUR search did not produce any results.  Change or reduce the filters and try again.',
//       noSearchFilterData: 'YOUR search did not product any results.  Change your search or filter criteria and try again.',
//     };
//   }

//   public static get filterConfigWithAllVendors(): IFilterConfig {
//     return {
//       operators: [filterOperators.eq, filterOperators.ne],
//       types: [
//         {
//           id: 'vendors',
//           label: '',
//           singleSelect: true,
//           values: [
//             {label: 'My Vendors', value: 'my-vendors'},
//             {label: 'All Vendors', value: 'all-vendors', selected: true},
//           ],
//         },
//       ],
//     };
//   }

//   /**
//    * Show search and date filters
//    * @returns {IFilterConfig}
//    */
//   public static get filterConfigWithDateAndSearch(): IFilterConfig {
//     return {
//       deselect: FilterDeselectBehavior.Remove,
//       search: {deselect: FilterDeselectBehavior.Remove},
//       dates: {
//         dateFrom: true,
//         dateTo: true,
//       },
//     };
//   }

//   public static get filterConfigWithStatusSeverity(): IFilterConfig {
//     return {
//       deselect: FilterDeselectBehavior.Toggle,
//       operators: [filterOperators.eq, filterOperators.ne],
//       types: [
//         {
//           id: 'status',
//           label: 'Status',
//           multiple: false,
//           values: [
//             {label: 'Reported', value: 'Reported'},
//             {label: 'Suspicious', value: 'Suspicious'},
//             {label: 'Not a Problem', value: 'NotAProblem'},
//             {label: 'Confirmed', value: 'Confirmed'},
//             {label: 'Remediated', value: 'Remediated'},
//           ],
//         },
//         {
//           id: 'severity',
//           label: 'Severity',
//           multiple: true,
//           selected: true,
//           values: [
//             {label: 'Very High', value: 'VeryHigh'},
//             {label: 'High', value: 'High'},
//             {label: 'Medium', value: 'Medium'},
//             {label: 'Low', value: 'Low'},
//             {label: 'Very Low', value: 'VeryLow', selected: true},
//             {label: 'Informational', value: 'Informational'},
//           ],
//         },
//       ],
//     };
//   }

//   public static get fullWidthCellRenderer(): Component {
//     return GridFullWidthRendererComponent;
//   }

//   public static get selectionConfig(): IActionSelectionConfig[] {
//     return [
//       {id: 'delete', label: 'Delete'},
//       {id: 'click', label: 'Click'},
//     ];
//   }

//   public static fetchNewData(gridConfig: GridConfig, gridService: GridExampleService) {
//     const {currentRowInPage, pageSize, sortColumn, filters} = gridConfig;
//     const params: IGridXhrParams = {
//       filters: filters,
//       rowNum: currentRowInPage,
//       numRows: pageSize,
//       sortColumn: sortColumn,
//     };

//     gridService
//       .getVulnerabilityData(params)
//       .subscribe((res: IGridXhrResponse) => gridConfig.setPageData(res));
//   }

//   public static pagingConfig(
//     pageSize: number, pageSizes: number[],
//     rowLabel = gridDefaults.pagingConfig.labels.rows): IPagingConfig {
//     return {
//       pageSize: pageSize,
//       pageSizes: pageSizes,
//       directNavigation: true,
//       labels: {
//         rows: rowLabel,
//       },
//     };
//   }

//   public static unsubscribe(subscriptions: Subscription[]) {
//     for (const subscription of subscriptions) {
//       subscription.unsubscribe();
//     }
//   }
// }
