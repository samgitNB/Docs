import {
  ModalExampleContentComponent,
} from '../modal/modal-example-content.component';

import {
  AlertBoxType,
  BadgeType,
  ButtonActionType,
  DateService,
  FilterDeselectBehavior,
  filterOperators,
  IActionSelectionConfig,
  IdleService,
  IFilterConfig,
  IPagingConfig,
  ITrainStopEntry,
  TrainStopImage,
  TrainStopSize,
} from 'vc-ux/lib';


import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ButtonType, HttpService } from 'vc-ux';


// for grid implmentation
import { GridConfig, IGridXhrParams, IGridXhrResponse } from 'vc-ux';
import { ColDef } from 'ag-grid';
import { Subscription } from 'rxjs/Subscription';
import { GridService } from '../../../services/grid-poc.service';
import { SpinnerService } from 'vc-ux/lib/feedback/components';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'poc-list',
  templateUrl: './poc-list.component.html',
  styleUrls: ['./poc-list.component.css']
})
export class PocListComponent implements OnInit {
  idleServiceRunning: boolean;

  closeResult: boolean;
  public readonly ButtonType = ButtonType;
  public columnDefs: ColDef[];
  public columnDefs2: ColDef[];

  public navJson: String;
  public someData: String = 'gateway =>';
  public localTime: Date;
  public readonly gridConfig: GridConfig = new GridConfig();
  public readonly gridConfig2: GridConfig = new GridConfig();
  private readonly subscriptions: Subscription[] = [];
  public readonly AlertBoxTypes = AlertBoxType;
  public readonly trainStopSize = TrainStopSize;
  public readonly BadgeTypes = BadgeType;
  public readonly myTitle;
  public viewTime = false;
  public timeAction = 'Show time';
  public idleAction: string;


  // train stop
  private readonly entries: ITrainStopEntry[] = [
    { label: 'Start', image: TrainStopImage.Check },
    { label: 'Step 1', image: TrainStopImage.Pencil, required: true },
    { label: 'Step 2' },
    { label: 'Completed', required: true },
  ];
  // Deep copy: entries are independent from each other
  public readonly entries1 = JSON.parse(JSON.stringify(this.entries));
  public readonly entries2 = JSON.parse(JSON.stringify(this.entries.slice(1)));
  public readonly entries3 = JSON.parse(JSON.stringify(this.entries.slice(2)));

  ngOnInit() {
    this.sessionTimeoutStart();
    this.idleAction = 'STOP';
  }

  constructor(
    private httpService: HttpService,
    private gridService: GridService,
    private router: Router,
    private modalService: NgbModal,
    private dateService: DateService,
    private spinnerService: SpinnerService,
    private idleService: IdleService) {

    this.localTime = new Date();
    this.myTitle = new Date();
    const { gridConfig, gridConfig2, subscriptions } = this;
    const { fetchData, actionSelectionButtonClicked } = gridConfig;

    // Grid view Header panel
    this.columnDefs = [
      { headerName: '', field: 'select', checkboxSelection: true, headerCheckboxSelection: true, suppressSorting: true, maxWidth: 30 },
      { headerName: 'ACCOUNT_ID', field: 'account_id', unSortIcon: false },
      { headerName: 'HOSTNAME', field: 'hostname', unSortIcon: true, filter: 'set' },
      { headerName: 'INSERT_TS', field: 'insert_ts', unSortIcon: true, filter: 'set' },
      { headerName: 'INSTANCE_ID', field: 'instance_id', unSortIcon: true, filter: 'set' },
      { headerName: 'IP_ADDRESS', field: 'ip_address', unSortIcon: true, filter: 'set' },
      { headerName: 'LOCATION', field: 'location', unSortIcon: true, filter: 'set' },
      { headerName: 'MODIFIED_TS', field: 'modified_ts', unSortIcon: true, filter: 'set' },
      { headerName: 'NAME', field: 'name', unSortIcon: true, filter: 'set' },
      { headerName: 'STATUS', field: 'status', unSortIcon: true, filter: 'set' },

    ];
    // subscribe to fetchData, which fires after page control and filter changes
    subscriptions.push(
      this.gridConfig2.fetchData.subscribe(() => this.fetchPocData(gridConfig2)),
    );


    this.loadData();
  }

  public fetchPocData(gridConfig: GridConfig) {

    const { currentRowInPage, pageSize, sortColumn, filters } = gridConfig; // @param

    const params: IGridXhrParams = {
      filters: filters,
      rowNum: currentRowInPage,
      numRows: pageSize,
      sortColumn: sortColumn,
    };
    this.spinnerService.show(89);
    this.gridService.getDataByHttpRequest(params).subscribe(res => {
      console.warn(res);
      const result: IGridXhrResponse = {
        rows: res.slice(currentRowInPage, currentRowInPage + pageSize),
        totalRowCount: res.length,
      };
      this.gridConfig2.setPageData(result);
      this.spinnerService.hide(89);
    },
      err => {
        const result: IGridXhrResponse = {
          rows: [],
          totalRowCount: 0,
        };
        this.gridConfig.setPageData(result);
        this.spinnerService.hide(89);
      });
  }

  private loadData = function () {
    this.httpService.getByFullPath('./testdata/poc-grid.data.json').subscribe(
      response => {
        this.someData = response._body;
      }
    );
  };

  public toggleTime() {
    if (!this.viewTime) {
      this.viewTime = true;
      this.timeAction = 'Show time';
    } else {
      this.viewTime = false;
      this.timeAction = 'Hide time';
    }
  }
  public onAddPressed() {
    this.router.navigate(['./poc-add']);
  }
  public clickIdleProcess() {

    if (this.idleServiceRunning === true) {
      const modalRef = this.modalService.open(ModalExampleContentComponent);
      // modalRef.componentInstance.name = 'vcux consumer ';
      modalRef.result.then((result) => {
        this.closeResult = result;
        this.idleServiceRunning = this.closeResult;
      // result = undefined ? this.idleServiceRunning = true : this.idleServiceRunning = false;
      if (this.idleServiceRunning === undefined) { this.idleServiceRunning = true; }
      }, (reason) => {
      });
    } else {
      alert('Idle Service already stop');
      this.idleServiceRunning = false;
    }
  }
  public sessionTimeoutStart() {
    if (!this.idleService.running) {
      this.idleAction = 'Stop';
      this.idleService.idleStart();
      this.idleService.setIdleTime(50);
      this.idleServiceRunning = true;
    }
  }

}
