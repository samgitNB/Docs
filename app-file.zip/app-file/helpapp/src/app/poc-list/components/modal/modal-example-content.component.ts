import { Action } from 'rxjs/scheduler/Action';
import { IdleService } from 'vc-ux/lib';
import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ButtonType } from 'vc-ux';

@Component({
  selector: 'vc-modal-content-example',
  templateUrl: './modal-example-content.component.html',
})
export class ModalExampleContentComponent {
  @Input() public name;
  public model;
  public readonly ButtonTypes = ButtonType;

  constructor(public activeModal: NgbActiveModal, private idleService: IdleService) {
  }

  public changeSessionMethod(value) {
    if (this.idleService.running) {
        this.model = false;
        this.idleService.idleStop();
        this.activeModal.close(this.model);
    }else {
      // console.log('allready stoped');
      // this.model = true;
      // this.activeModal.close(this.model);
    }

  }
}
