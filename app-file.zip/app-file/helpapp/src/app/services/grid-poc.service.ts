import { Injectable } from '@angular/core';

import { Http, RequestOptionsArgs, Headers } from '@angular/http';
import { GlobalsService, HttpService, IGridXhrParams } from 'vc-ux';
import 'rxjs/add/operator/map';



@Injectable()
export class GridService {

  // addr = './testdata/poc-grid.data.json';
  addr = 'https://b5n4iqanu4.execute-api.us-east-1.amazonaws.com/dev_admin/v1/gateways';

  constructor(private http: Http, private httpService: HttpService, private globalsService: GlobalsService) { }

  public getDataByHttpRequest(params?: IGridXhrParams) {
    return this.http
      .get(this.addr)
      .map(res => res.json())
      .catch(e => { console.warn('GridService error'); throw e; });
  }

  public loadAPI() {
    return this.http
      .get(this.addr)
      .map(res => res.json())
      .catch(e => { console.warn('GridService error'); throw e; });
  }
  // use vcux service set CROS
  public getDataByHttpServiceRequest(params?: IGridXhrParams) {
    return this.httpService
      .getByFullPath(this.addr)
      .map(res => res.json())
      .catch(e => { console.warn('GridService error'); throw e; });
  }




}
