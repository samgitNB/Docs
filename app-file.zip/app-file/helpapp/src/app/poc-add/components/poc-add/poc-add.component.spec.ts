import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PocAddComponent } from './poc-add.component';

describe('PocAddComponent', () => {
  let component: PocAddComponent;
  let fixture: ComponentFixture<PocAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PocAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PocAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
