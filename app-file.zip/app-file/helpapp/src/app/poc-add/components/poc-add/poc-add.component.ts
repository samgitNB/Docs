import { Router } from '@angular/router';
import { ModalExampleContentComponent } from '../modal/modal-example-content.component';


import { GridService } from '../../../services/grid-poc.service';
import {
  AlertBoxType,
  BadgeHeightType,
  BadgeType,
  BadgeWidthType,
  ITrainStopEntry,
  LoggerService,
  MessageService,
  SpinnerService,
  TrainStopImage,
  TrainStopSize,
} from 'vc-ux/lib';
import { Component, OnInit } from '@angular/core';
import { Logger } from 'log4javascript';
import { ButtonType, HttpService } from 'vc-ux';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'poc-add',
  templateUrl: './poc-add.component.html',
  styleUrls: ['./poc-add.component.css']
})
export class PocAddComponent implements OnInit {
  closeResult: string;
  public alertTitle: string;
  private logger: Logger;
  public readonly ButtonType = ButtonType;
  public readonly trainStopSize = TrainStopSize;
  public readonly AlertBoxTypes = AlertBoxType;
  public readonly BadgeTypes = BadgeType;
  public readonly BadgeHeightTypes = BadgeHeightType;
  public readonly BadgeWidthTypes = BadgeWidthType;
  public listapi: ListData[] = [];
  private account_id: string;
  private name: string;
  private successAlert = false;


  // train stop
  private readonly entries: ITrainStopEntry[] = [
    { label: 'Start', image: TrainStopImage.Check },
    { label: 'Step 1', image: TrainStopImage.Check, required: true },
    { label: 'Step 2', image: TrainStopImage.Pencil, required: true },
    { label: 'Completed', required: true },
  ];
  // Deep copy: entries are independent from each other
  public readonly entries1 = JSON.parse(JSON.stringify(this.entries));
  public readonly entries2 = JSON.parse(JSON.stringify(this.entries.slice(1)));
  public readonly entries3 = JSON.parse(JSON.stringify(this.entries.slice(2)));


  constructor(private loggerService: LoggerService,
    private gridService: GridService,
    private spinnerService: SpinnerService,
    private modalService: NgbModal,
    private messageService: MessageService,
    private router: Router,
  ) {
    // set up logger
    this.logger = loggerService.getLogger('PocAddComponent');
    this.logger.info('error message will be displayed');
    this.logger.error('error message will be displayed ');

    const { entries1 } = this;

    entries1.forEach((entry: ITrainStopEntry) => {
     // entry.clickable = true;
      // entry.label += ' (Clickable)';
      entries1[1].clickable = true;
      // entries1[2].label = 'Home';
    });

  }

  ngOnInit() {
  }
  public onPressed() {
    // this.spinnerService.show(2);
    this.gridService.loadAPI().subscribe(res => {
      this.listapi = res;
      this.successAlert = true;
      this.alertTitle = 'Successfully Loaded!';
      this.logger.info('load api data');
    }, err => {
      this.successAlert = true;
      this.logger.error('load api data');
      this.alertTitle = 'Error while Loading Status';
    });
  }


  public onPressedAdd() {
    if (this.account_id !== undefined) {
      this.messageService.addSuccessMessage(this.name + '  Record is Added ');
    } else {
      this.messageService.addWarningMessage('Input Feilds are Empty');

    }
  }
  public clicked(id: string) {
   // alert('Clicked: ' + id);
   this.router.navigate(['./poc-list']);
  }
}

export interface ListData {
  name: string;
  account_id: string;
  hostname: string;
  ip_address: string;
  location: string;
  modified_ts: string
}
