import {Component, Input} from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {ButtonType} from 'vc-ux';

@Component({
  selector: 'vc-modal-content-example',
  templateUrl: './modal-example-content.component.html',
})
export class ModalExampleContentComponent {
  @Input() public name;

  public readonly ButtonTypes = ButtonType;
  constructor(public activeModal: NgbActiveModal) {
  }

}
