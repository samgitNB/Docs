import { ModalExampleContentComponent } from './components/modal/modal-example-content.component';

import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PocAddComponent } from './components/poc-add/poc-add.component';
import {TranslateModule} from '@ngx-translate/core';
import {GlobalsModule, GlobalsService, UXPatternsModule} from 'vc-ux';

import { GridService} from '../services/grid-poc.service';

@NgModule({
  imports: [
    CommonModule,
    UXPatternsModule,
    CommonModule,
    BrowserModule,
    FormsModule,
    HttpModule,
    UXPatternsModule,
    GlobalsModule,
  ],
  providers: [
    GridService,
    GlobalsService
  ],
  declarations: [PocAddComponent , ModalExampleContentComponent],
  exports: [ PocAddComponent],
  entryComponents: [ModalExampleContentComponent],
})
export class PocAddModule { }
