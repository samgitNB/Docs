import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApplicationListComponent } from './components/application-list/application-list.component';

import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {GlobalsModule, GlobalsService, UXPatternsModule} from 'vc-ux';
import { PartialLoaderModule } from 'vc-ux';
import {TranslateModule} from '@ngx-translate/core';
import {GridService} from '../grid-example.service';

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    HttpModule,
    UXPatternsModule,
    TranslateModule,
    PartialLoaderModule.forRoot({
      lang: 'en',
      prefix: '/assets/i18n',
      suffix: '.json',
    }),
    GlobalsModule,
  ],
  providers: [
    GridService,
    GlobalsService,
  ],
  declarations: [ApplicationListComponent],
  exports: [ApplicationListComponent]
})
export class ApplicationListModule { }
