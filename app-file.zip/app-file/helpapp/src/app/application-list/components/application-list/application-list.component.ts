import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import {
  ButtonType,
  HttpService,
} from 'vc-ux';

// for grid
import {
  GridConfig,
  IGridXhrParams,
  IGridXhrResponse,
} from 'vc-ux';
import { ColDef} from 'ag-grid';
import { Subscription } from 'rxjs/Subscription';
import { GridService } from '../../../grid-example.service';
import {SpinnerService} from 'vc-ux/lib/feedback/components';

@Component({
  selector: 'application-list',
  templateUrl: './application-list.component.html',
  styleUrls: ['./application-list.component.css']
})
export class ApplicationListComponent implements OnInit {

  public ButtonType = ButtonType;

  public someData = 'some data';
  public columnDefs: ColDef[];
  public columnDefs2: ColDef[];

  public navJson: String;

  public readonly gridConfig: GridConfig = new GridConfig();
  public readonly gridConfig2: GridConfig = new GridConfig();
  private readonly subscriptions: Subscription[] = [];

  ngOnInit() {
  }

  // only way to get service in is via constructor
  constructor(private httpService: HttpService,
              private gridService: GridService,
              private router: Router,
              private spinnerService: SpinnerService,
  ) {

    const {gridConfig, gridConfig2, subscriptions} = this;
    const {fetchData, actionSelectionButtonClicked} = gridConfig;

    // this.loadData();

    this.columnDefs = [
      {headerName: '', field: 'select', checkboxSelection: true, headerCheckboxSelection: true, suppressSorting: true, maxWidth: 30},
      {headerName: 'Severity', field: 'severity', unSortIcon: true},
      {headerName: 'Cwe Id', field: 'cwe_id', unSortIcon: true, filter: 'set'},
      {headerName: 'Date Discovered', field: 'first_time_seen', unSortIcon: true},
      {headerName: 'Date Last Seen', field: 'last_time_seen', sort: 'desc', unSortIcon: true},
      {headerName: 'Agent Status', field: 'status', unSortIcon: true},
    ];

    this.columnDefs2 = [
      {headerName: 'Finding Status', field: 'finding_status', unSortIcon: true,
        cellRenderer: (params) => { return params.value.status; } },
      {headerName: 'Description', field: 'description' },
    ];

    // subscribe to fetchData, which fires after page control and filter changes
    subscriptions.push(
      fetchData.subscribe(() => this.fetchMyData(gridConfig)),
      this.gridConfig2.fetchData.subscribe(() => this.fetchMyData2(gridConfig2)),
    );

    this.loadData();
  }

  private loadData = function() {
    this.httpService.getByFullPath('https://jsonplaceholder.typicode.com/posts').subscribe(
      response => { this.someData = response._body; }
    );

  };

  public fetchMyData(gridConfig: GridConfig) { // }, gridService: GridExampleService) {
    const {currentRowInPage, pageSize, sortColumn, filters} = gridConfig;

    const params: IGridXhrParams = {
      filters: filters,
      rowNum: currentRowInPage,
      numRows: pageSize,
      sortColumn: sortColumn,
    };

    this.spinnerService.show(89);

    this.gridService.getFindingsData(params).subscribe(
      res => {
        console.warn (res);
        const result: IGridXhrResponse = {
          rows: res._embedded.findings.slice(currentRowInPage, currentRowInPage + pageSize),
          totalRowCount: res._embedded.findings.length,
        };
        this.gridConfig.setPageData(result);
        this.spinnerService.hide(89);
      },
      err => {
        const result: IGridXhrResponse = {
          rows: [],
          totalRowCount: 0,
        };
        this.gridConfig.setPageData(result);
        this.spinnerService.hide(89);
      }
    );

  }

  public fetchMyData2(gridConfig: GridConfig) {
    const {currentRowInPage, pageSize, sortColumn, filters} = gridConfig;

    const params: IGridXhrParams = {
      filters: filters,
      rowNum: currentRowInPage,
      numRows: pageSize,
      sortColumn: sortColumn,
    };

    this.gridService.getVulnerabilityData(params).subscribe(res => {
      console.warn (res);
      const result: IGridXhrResponse = {
        rows: res.vulnerabilities.slice(currentRowInPage, currentRowInPage + pageSize),
        totalRowCount: res.vulnerabilities.length,
      };
      this.gridConfig2.setPageData(result);
    });
  }

  public onButtonPressed(message) {
    alert(message);
  }

  public onAddPressed() {
   this.router.navigate(['./application-add']);
  }

  public handleSelection(event) {
    console.log('rows selected:', event.map(row => row.id));
  }

}
