import { PocAddComponent } from './poc-add/components/poc-add/poc-add.component';
import { RouterModule, Routes } from '@angular/router';
// rout components
import { PocListComponent } from './poc-list/components/poc-list/poc-list.component';
import { ApplicationListComponent } from './application-list';
import { ApplicationAddComponent } from './application-add';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'poc-list',
    pathMatch: 'full'
  },
  {
    path: 'application-list',
    component: ApplicationListComponent
  },
  {
    path: 'application-add',
    component: ApplicationAddComponent
  },


  {
    path: 'poc-list',
    component: PocListComponent
  },
  {
    path: 'poc-add',
    component: PocAddComponent
  }
];

export const routing = RouterModule.forRoot(routes, { useHash: true });
