import { Component } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Logger } from 'log4javascript';

import {
  ClickUtilService,
  GlobalsService,
  HttpService,
  IdleService,
  LoggerService,
  PartialLoaderService,
} from 'vc-ux';

import { GridService } from './grid-example.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'app works!';
  title2 = 'Application Findings';

  public navJson: String;

  private logger: Logger;
  public ready = true;

  // only way to get service in is via constructor
  constructor(private httpService: HttpService,
              private gridService: GridService,
              private partial: PartialLoaderService,
              private http: Http,
              private loggerService: LoggerService,
              private globalsService: GlobalsService,
              private clickUtilService: ClickUtilService,
              private idleService: IdleService,
              )  {
    // set up logger
    this.logger = loggerService.getLogger();

    // set up translations
    this.partial.setLang('en');
    this.partial.addPartials(['sample_messages', 'en']);

    // set up idleService
    if (! this.idleService.running) {
     // this.idleService.idleStart();
    }
    // initialize uigateway value
    http.get('/resources/config/config.json')
      .map(res => res.json())
      .catch((err: any) => {
        this.logger.error('http.get - Error! ' + err.toString());
        return Observable.throw(err);
      })
      .subscribe(config => {
        // set up the Globals service here.
        this.globalsService.uigateway = config.uigateway;
        console.warn(this.globalsService.uigateway);
        this.logger.info('UIGateway is ' + config.uigateway);
        this.loadData();
      })
    ;

  }
// end construtor

  private loadData = function() {
    this.gridService.getNavigation().subscribe(res => {
      console.warn (res);
      this.navJson = res;
      this.ready = true;
    }, error => {
      console.warn('got an error');
      this.clickUtilService.logout();
      this.ready = true;
    });

  };

}
