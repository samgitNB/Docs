import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import {ModalExampleContentComponent} from './modal-example-content.component';

@Component({
  selector: 'application-add',
  templateUrl: './application-add.component.html',
  styleUrls: ['./application-add.component.css']
})
export class ApplicationAddComponent implements OnInit {
  private closeResult;

  constructor(private modalService: NgbModal) { }

  ngOnInit() {
  }

  public changePaymentMethod() {
    const modalRef = this.modalService.open(ModalExampleContentComponent);
    modalRef.componentInstance.name = 'World';

    modalRef.result.then((result) => {
      this.closeResult = `Closed with ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed reason`;
    });
  };

}
