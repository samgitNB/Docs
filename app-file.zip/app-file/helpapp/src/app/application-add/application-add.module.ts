import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApplicationAddComponent } from './components/application-add/application-add.component';
import { UXPatternsModule } from 'vc-ux';
import {ModalExampleContentComponent} from './components/application-add/modal-example-content.component';
import { FormsModule} from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    UXPatternsModule,
    FormsModule,
  ],
  declarations: [ApplicationAddComponent, ModalExampleContentComponent],
  exports: [ApplicationAddComponent],
  entryComponents: [ModalExampleContentComponent],
})
export class ApplicationAddModule { }
