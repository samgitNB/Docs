#!/bin/sh

# declare default aws parameters for tests

mkdir ~/.aws

echo configure aws profile
cat >~/.aws/config <<HERE
[default]
region = us-east-1
s3 =
    signature_version = s3v4
[profile nonprod]
region = us-east-1
s3 =
    signature_version = s3v4
HERE

echo configure aws credentials
cat >~/.aws/credentials <<HERE
[nonprod]
aws_access_key_id = $NONPROD_AWS_ACCESS_KEY_ID
aws_secret_access_key = $NONPROD_AWS_SECRET_ACCESS_KEY
HERE