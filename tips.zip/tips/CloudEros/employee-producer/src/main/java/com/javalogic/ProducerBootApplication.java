package com.javalogic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ProducerBootApplication {
    public static void main(String[] args) {
        SpringApplication.run(ProducerBootApplication.class, args);
        System.out.println("\n-------- Producer Application is running ----- ");
    }
}
