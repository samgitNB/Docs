package com.javalogic;

import com.javalogic.controllers.ConsumerControllerClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import java.io.IOException;

@SpringBootApplication
public class ConsumerBootApplication {
    public static void main(String[] args) throws IOException {


        ApplicationContext ctx = SpringApplication.run(ConsumerBootApplication.class, args);

        ConsumerControllerClient consumerControllerClient = ctx.getBean(ConsumerControllerClient.class);
        System.out.println(consumerControllerClient);
        consumerControllerClient.getEmployee();

        System.out.println("\n-------- Consumer Application is Invoking Producer  ----- ");

    }

    /*
    * Java base - Application configuration
    * @Bean get ConsumerControllerClient object
    * */

    @Bean
    public ConsumerControllerClient consumerControllerClient() {
        return new ConsumerControllerClient();
    }
}
