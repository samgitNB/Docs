package com.voodram.boot;

import com.voodram.model.Domain;
import com.voodram.repository.DomainRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;

@SpringBootApplication
@ComponentScan("com.voodram")
public class RegionApplication {


    public static void main(String[] args) {
        SpringApplication.run(RegionApplication.class, args);
        System.out.println("\n<<<<<<<<<<< : RegionApplication Running : >>>>>>>>>>");
    }

}
