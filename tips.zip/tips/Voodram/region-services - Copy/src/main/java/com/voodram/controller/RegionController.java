package com.voodram.controller;


import com.voodram.model.Domain;
import com.voodram.model.Region;
import com.voodram.repository.DomainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@ComponentScan("com.voodram")
public class RegionController {

    @Autowired
    DomainRepository domainRepository;

    @RequestMapping("/")
    public String version(){
        return "2.1.0-RELEASE";
    }

    @RequestMapping(value = "/view", method = RequestMethod.GET)
    public void find(){
        // domainRepository.findByFirstName("org");
    }

}
