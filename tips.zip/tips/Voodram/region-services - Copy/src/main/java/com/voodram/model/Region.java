package com.voodram.model;

public class Region {

}
