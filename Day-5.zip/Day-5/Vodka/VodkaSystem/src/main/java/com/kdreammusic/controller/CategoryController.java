package com.kdreammusic.controller;

import com.kdreammusic.model.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.List;

@Controller
public class CategoryController {

    @Autowired
    private DiscoveryClient discoveryClient;

    public void findAll() {

        List<ServiceInstance> instances = discoveryClient.getInstances("Vodka");
        ServiceInstance serviceInstance = instances.get(0);

        String baseUrl = serviceInstance.getUri().toString();
        baseUrl = baseUrl + "/categories";

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<List<Category>> response = null;
        try {
            response = restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), new ParameterizedTypeReference<List<Category>>() {
            });
        } catch (Exception ex) {
            System.out.println(ex);
        }

        List<Category> categories = response.getBody();
        for (Category category : categories) {
            System.out.println(category.getName());
        }
    }

    private static HttpEntity<?> getHeaders() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(headers);
    }
}
