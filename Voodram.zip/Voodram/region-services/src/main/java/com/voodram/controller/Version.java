package com.voodram.controller;


import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RefreshScope
@RestController
public class Version {

    @RequestMapping("/")
    public String version(){
        return "2.1.0-RELEASE";
    }
}
