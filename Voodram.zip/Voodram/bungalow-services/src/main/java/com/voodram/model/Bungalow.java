package com.voodram.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "bungalow")
public class Bungalow {

    @Id
    private String bungalowCode;
    private String name;
    private Region region;
    private String bungalowRate;
    private String address;
    private String contactNumber;
    private String bungalowImageURL;
    private String maximumOccupancy;

    public String getBungalowCode() {
        return bungalowCode;
    }

    public void setBungalowCode(String bungalowCode) {
        this.bungalowCode = bungalowCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Region getRegion() {
        return region;
    }

    public void setRegion(Region region) {
        this.region = region;
    }

    public String getBungalowRate() {
        return bungalowRate;
    }

    public void setBungalowRate(String bungalowRate) {
        this.bungalowRate = bungalowRate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getBungalowImageURL() {
        return bungalowImageURL;
    }

    public void setBungalowImageURL(String bungalowImageURL) {
        this.bungalowImageURL = bungalowImageURL;
    }

    public String getMaximumOccupancy() {
        return maximumOccupancy;
    }

    public void setMaximumOccupancy(String maximumOccupancy) {
        this.maximumOccupancy = maximumOccupancy;
    }


}
