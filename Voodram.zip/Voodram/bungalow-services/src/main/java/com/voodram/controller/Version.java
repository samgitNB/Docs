package com.voodram.controller;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RefreshScope
@Component
@RestController
public class Version {

    @Value("${message: RELEASE 1.0.0}")
    String message;

    @RequestMapping("/")
    public String version(){
        return message;
    }

}
