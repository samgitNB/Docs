package com.voodram.util;

public class BungalowConstants {


    public static final String DATABASE_DRIVER = "";
    public static final String DATABASE_PASSWORD = "";
    public static final String DATABASE_USERNAME = "";
    public static final String DATABASE_NAME = "database.mongo.name";
    public final static String HOST_NAME = "database.mongo.host";
    public final static String PORT = "database.mongo.port";


}
