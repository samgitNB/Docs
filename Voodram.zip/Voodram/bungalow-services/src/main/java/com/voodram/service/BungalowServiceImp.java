package com.voodram.service;

import com.voodram.model.Bungalow;
import com.voodram.model.Region;
import com.voodram.repository.BungalowRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.List;

@Service
public class BungalowServiceImp implements BungalowService {

    @Autowired
    BungalowRepository bungalowRepository;

    @Autowired
    DiscoveryClient discoveryClient;

    @Override
    public void save(Bungalow bungalow) {

        Bungalow isBungalowExist = bungalowRepository.findByName(bungalow.getName());
        //Inter service call-----------
        List<ServiceInstance> instances = discoveryClient.getInstances("region-service");
        ServiceInstance serviceInstance = instances.get(0);


        String url = serviceInstance.getUri().toString();
        String baseUrl = url + "/regions/code/" + bungalow.getRegion().getCode();

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Region> region = null;
        try {
            region = restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), Region.class);
        } catch (Exception ex) {
        }
        Region region_2 = region.getBody();


        if (isBungalowExist == null && region_2 == null) {
            bungalow.setRegion(region_2);
            bungalowRepository.save(bungalow);
        }
    }

    public HttpEntity getHeaders() throws IOException {

        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(headers);
    }


    @Override
    public List<Bungalow> findAll() {
        return bungalowRepository.findAll();
    }

    @Override
    public Bungalow update(Bungalow reg, String id) {
        Bungalow isExist = bungalowRepository.findById(id);
        Bungalow bungalow = new Bungalow();
        if (id != null && isExist != null) {
            bungalow.setBungalowCode(id);
            bungalow.setName(reg.getName());
            bungalow = bungalowRepository.update(bungalow);
        }
        return bungalow;
    }

    @Override
    public boolean deleteByName(String name) {

        Bungalow isBungalowExist = bungalowRepository.findByName(name);
        if (isBungalowExist != null) {
            bungalowRepository.deleteByName(name);
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteById(String id) {
        Bungalow isBungalowExist = bungalowRepository.findById(id);
        if (isBungalowExist != null) {
            bungalowRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public Bungalow findByName(String name) {
        return bungalowRepository.findByName(name);
    }

    @Override
    public Bungalow findById(String id) {
        return bungalowRepository.findById(id);
    }


}
