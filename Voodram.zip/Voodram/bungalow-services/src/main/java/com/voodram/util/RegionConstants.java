package com.voodram.util;

public class RegionConstants {



	/**
	 *to hold database name
	 */
	final public static String DATABASE_NAME = "bungalowDB";
	/**
	 *to hold host name
	 */
	final public static String HOST_NAME = "localhost";
	/**
	 *to hold port number
	 */
	final public static Integer PORT = 27017;

	/**
	 *to hold collection name
	 */
	final public static String COLLECTION_NAME = "bungalow";

	


}
