package com.sample.step1;

import java.util.List;

/**
 * Created by sameera on 8/8/17.
 */
public interface StudentDAO {

     List<String> getAllStudentName();
}
