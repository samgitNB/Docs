package com.sample.step1;

import java.util.Arrays;
import java.util.List;

public class MongoDAO implements StudentDAO {



    @Override
    public List<String> getAllStudentName() {

        System.out.println("***** Student from [ MONGO Database ] *****");
        return Arrays.asList("JACK","MIKE","DANIAL");
    }
}
