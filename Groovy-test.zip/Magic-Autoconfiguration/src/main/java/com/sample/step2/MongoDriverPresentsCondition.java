package com.sample.step2;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * Created by sameera on 8/8/17.
 */


public class MongoDriverPresentsCondition implements Condition{
    @Override
    public boolean matches(ConditionContext conditionContext, AnnotatedTypeMetadata annotatedTypeMetadata) {

        try {
            Class.forName("com.sample2.Server");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }

    }
}
