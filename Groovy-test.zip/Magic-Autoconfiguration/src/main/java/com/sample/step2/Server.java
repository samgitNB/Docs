package com.sample.step2;

/**
 * Created by sameera on 8/8/17.
 */
public class Server {
}
