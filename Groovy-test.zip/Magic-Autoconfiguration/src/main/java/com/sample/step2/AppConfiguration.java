package com.sample.step2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;



@Configuration
public class AppConfiguration {

    @Bean
    @Conditional(MongoDriverNotPresentsCondition.class)
    public StudentDAO jdbcUserDAO(){
        return new MysqlDAO();
    }


    @Bean
    @Conditional(MongoDriverPresentsCondition.class)
    public StudentDAO mongoUserDAO(){
        return new MongoDAO();
    }

}
