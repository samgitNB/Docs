package com.sample.step3;

import java.util.Arrays;
import java.util.List;

public class MysqlDAO implements StudentDAO {


    @Override
    public List<String> getAllStudentName() {
        System.out.println("***** Student from [ MYSQL Database ] *****");
        return Arrays.asList("LARA","SUSAN","MAYA");
    }
}
