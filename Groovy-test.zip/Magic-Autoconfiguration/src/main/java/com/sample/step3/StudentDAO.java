package com.sample.step3;

import java.util.List;

/**
 * Created by sameera on 8/8/17.
 */
public interface StudentDAO {

     List<String> getAllStudentName();
}
