package com.sample.step3;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;


@Configuration
public class AppConfiguration {

    @Bean
    @DatabaseType("MYSQL")
    public StudentDAO jdbcUserDAO(){
        return new MysqlDAO();
    }


    @Bean
    @DatabaseType("MONGO")
    public StudentDAO mongoUserDAO(){
        return new MongoDAO();
    }

}
