package com.study.model

class Customer {

    /*
    * Groovy Generates setter/getter by for us
    * */

    private def id;
    private def name;
    private def city;

    Customer() {}

    def getId() {
        return id
    }

    void setId(id) {
        this.id = id
    }

    def getName() {
        return name
    }

    void setName(name) {
        this.name = name
    }

    def getCity() {
        return city
    }

    void setCity(city) {
        this.city = city
    }
}
