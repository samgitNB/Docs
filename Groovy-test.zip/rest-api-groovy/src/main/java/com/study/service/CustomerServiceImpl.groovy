package com.study.service

import com.study.repository.CusRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service


@Service
class CustomerServiceImpl implements CusService{

    @Autowired
    private CusRepository  cusRepository
    //private def CusRepository cusRepository

    @Override
    def getAllCustomerNames() {
        return cusRepository.allCustomerNames()
    }
}
