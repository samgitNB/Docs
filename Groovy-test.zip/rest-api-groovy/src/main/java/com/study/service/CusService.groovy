package com.study.service

import org.springframework.stereotype.Service


interface CusService {



    def getAllCustomerNames()

}