package com.study.controller

import com.study.service.CusService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController



@RequestMapping("/customer")
@RestController
class CustomerController {


    @Autowired
    private CusService cusService


    @RequestMapping("/version")
    def version(){
        return "Project version : 1.0.2"
    }

    @RequestMapping("/all")
    def getAllCustomerName(){
        return cusService.allCustomerNames()
    }


}
