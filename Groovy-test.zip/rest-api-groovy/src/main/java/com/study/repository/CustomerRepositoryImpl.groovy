package com.study.repository

import com.study.model.Customer
import org.springframework.stereotype.Repository

@Repository
class CustomerRepositoryImpl implements CusRepository {


    private static Map<Integer, Customer> db = new HashMap<>()

    static {
        def customer = new Customer()
        customer.setId(1)
        customer.setName("Jone")
        customer.setCity("Colombo")

        db.put(1, customer)
    }


    @Override
    def getAllCustomerNames() {
        return db.values()
    }
}
