package com.study.repository

import org.springframework.stereotype.Repository


interface CusRepository {

   def getAllCustomerNames()

}