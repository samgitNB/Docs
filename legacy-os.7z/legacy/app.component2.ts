import { Component, Inject } from '@angular/core';
import { HttpService } from 'vc-ux';
import {IDatasource, IGetRowsParams, ColDef} from 'ag-grid';
import {GridService} from '../services/grid-example.service';
// This would be an explicit reference to the types file
 import { ButtonType } from 'vc-ux/lib/buttons/types/button-type.type';
// import { ButtonType } from 'vc-ux';
import { PartialLoaderService } from 'vc-ux';
import { GridConfig } from 'vc-ux';
import { Subscription } from 'rxjs/Subscription';
// for grid
import {
  filterIds,
  filterOperators,
  IFilterSelected,
  IGridXhrParams,
  IGridXhrResponse,
  IRowAccess,
} from 'vc-ux';

@Component({
  selector: 'app-root',
  templateUrl: './app.component2.html',
  // providers: [Location, {provide: LocationStrategy, useClass: PathLocationStrategy}],
  styleUrls: ['../app.component.css']
})

export class AppComponent {
  title = 'app works!';
  title2 = 'Application Findings';

  public ButtonType = ButtonType;

  public someData = 'some data';
  public columnDefs: ColDef[];
  public columnDefs2: ColDef[];

  public navJson: String;

  public readonly gridConfig: GridConfig = new GridConfig();
  public readonly gridConfig2: GridConfig = new GridConfig();
  private readonly subscriptions: Subscription[] = [];

  // only way to get service in is via constructor
  constructor(private httpService: HttpService,
              private gridService: GridService,
              private partial: PartialLoaderService,
              ) {
    this.partial.setLang('en');
    this.partial.addPartials(['uxpatterns_messages', 'sample_messages']);

    const {gridConfig, gridConfig2, subscriptions} = this;
    const {fetchData, actionSelectionButtonClicked} = gridConfig;

    this.loadData();

    this.columnDefs = [
      {headerName: '', field: 'select', checkboxSelection: true, headerCheckboxSelection: true, suppressSorting: true, maxWidth: 30},
      {headerName: 'Severity', field: 'severity', unSortIcon: true},
      {headerName: 'Cwe Id', field: 'cwe_id', unSortIcon: true, filter: 'set'},
      {headerName: 'Date Discovered', field: 'first_time_seen', unSortIcon: true},
      {headerName: 'Date Last Seen', field: 'last_time_seen', sort: 'desc', unSortIcon: true},
      {headerName: 'Agent Status', field: 'status', unSortIcon: true},
    ];

    this.columnDefs2 = [
      {headerName: 'Finding Status', field: 'finding_status', unSortIcon: true,
        cellRenderer: (params) => { return params.value.status; } },
      {headerName: 'Description', field: 'description' },
    ];

    // subscribe to fetchData, which fires after page control and filter changes
    subscriptions.push(
      fetchData.subscribe(() => this.fetchMyData(gridConfig)),
      this.gridConfig2.fetchData.subscribe(() => this.fetchMyData2(gridConfig2)),
      );
  }

  public fetchMyData(gridConfig: GridConfig) { // }, gridService: GridExampleService) {
    const {currentRowInPage, pageSize, sortColumn, filters} = gridConfig;

    const params: IGridXhrParams = {
      filters: filters,
      rowNum: currentRowInPage,
      numRows: pageSize,
      sortColumn: sortColumn,
    };

    this.gridService.getFindingsData(params).subscribe(
      res => {
        console.warn (res);
        const result: IGridXhrResponse = {
          rows: res._embedded.findings.slice(currentRowInPage, currentRowInPage + pageSize),
          totalRowCount: res._embedded.findings.length,
        };
        this.gridConfig.setPageData(result);
      },
      err => {
        const result: IGridXhrResponse = {
          rows: [],
          totalRowCount: 0,
        };
        this.gridConfig.setPageData(result);
      }
    );

  }

  public fetchMyData2(gridConfig: GridConfig) {
    const {currentRowInPage, pageSize, sortColumn, filters} = gridConfig;

    const params: IGridXhrParams = {
      filters: filters,
      rowNum: currentRowInPage,
      numRows: pageSize,
      sortColumn: sortColumn,
    };

    this.gridService.getVulnerabilityData(params).subscribe(res => {
      console.warn (res);
      const result: IGridXhrResponse = {
        rows: res.vulnerabilities.slice(currentRowInPage, currentRowInPage + pageSize),
        totalRowCount: res.vulnerabilities.length,
      };
      this.gridConfig2.setPageData(result);
    });
  }

  private loadData = function() {
    this.httpService.getByFullPath('https://jsonplaceholder.typicode.com/posts').subscribe(
      response => { console.info(response); this.someData = response._body; }
    );

    this.gridService.getNavigation().subscribe(res => {
      console.warn (res);
      this.navJson = res;
    }, error => {
      console.warn('got an error');
      //window.location.href = 'https://localhost:3000';
    });


  };

  public onButtonPressed(message) {
    alert(message);
  }

  public handleSelection(event) {
    console.log('rows selected:', event.map(row => row.id));
  }
}
