package com.voodram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegionApplication {

/*
* bagalor id/name/rooms
*
*
 * .localy ->shre->aapplication (hideen show)
  *
  * */




    public static void main(String[] args) {
        SpringApplication.run(RegionApplication.class, args);
        System.out.println("\n<<<<<<<<<<< : RegionApplication Running : >>>>>>>>>>");
    }

}
