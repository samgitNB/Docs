package com.self.tutorials.service;

import com.self.tutorials.model.Employee;
import com.self.tutorials.repository.EmployeeRipository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService {


    @Autowired
    private EmployeeRipository employeeRipository;

    @Override
    public void save(Employee employee) {

        employeeRipository.save(employee);
    }

    @Override
    public Employee getEmployee(Integer id) {

        return employeeRipository.getEmployee(id);
    }
}
