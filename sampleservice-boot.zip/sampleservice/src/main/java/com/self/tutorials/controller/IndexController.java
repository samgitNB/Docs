package com.self.tutorials.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {

	@RequestMapping("/now")
	public String home(Map<String, Object> model) {
		model.put("message", "This About us of SAMEERA");
		return "index";
	}
	
	@RequestMapping("/next")
	public String next(Map<String, Object> model) {
		model.put("message", "Project sample of the SAMEERA");
		return "next";
	}

	@RequestMapping("/now2")
	public String demo(Model model) {
		model.addAttribute("zoom","Can we have a testing ......");
		return "index";
	}

}