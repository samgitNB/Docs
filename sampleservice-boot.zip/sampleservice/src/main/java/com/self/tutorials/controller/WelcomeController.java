package com.self.tutorials.controller;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@Controller
public class WelcomeController {

    //@Value("${welcome.message:test}")
    private String message = "Hello World";

    @RequestMapping("/demo")
    public String welcome(Model model) {

        model.addAttribute("message",message);
        return "page.html";
    }



}
