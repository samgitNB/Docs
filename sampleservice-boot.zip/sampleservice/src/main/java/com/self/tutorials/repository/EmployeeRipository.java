package com.self.tutorials.repository;


import com.self.tutorials.model.Employee;

public interface EmployeeRipository {

    void save (Employee employee);
    Employee getEmployee(Integer id);
}
