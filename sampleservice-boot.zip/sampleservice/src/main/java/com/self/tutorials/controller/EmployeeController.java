package com.self.tutorials.controller;


import com.self.tutorials.model.Employee;
import com.self.tutorials.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class EmployeeController {


    @RequestMapping("/welcome")
    public String welcome(){

        return "Welcome to Employee Management System..";
    }
    // inject via application.properties
    //@Value("${app.welcome.message}")
    private String MESSAGE = "SAMEERA";

    //@Value("${app.welcome.title}")
    private String TITLE = "TEST";



    @Autowired
    EmployeeService employeeService;

    @RequestMapping(value = "/hrm/emp/{id}" ,method = RequestMethod.GET)
    public Employee getEmployee(@PathVariable("id") Integer id) {

        return employeeService.getEmployee(id);
    }


}
