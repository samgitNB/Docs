package com.self.tutorials.repository;

import com.self.tutorials.model.Employee;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeRipositoryImpl implements EmployeeRipository{

    @Override
    public void save(Employee employee) {

        System.out.println(employee.getName() + "s  record has been saved..");
    }

    /*
    * crate session in hibernate
    * crate sql query for retrieve the emp details from database
    * @param = emp-id
    * @return employee obj which relate to = > id
    * */
    @Override
    public Employee getEmployee(Integer id) {

        Employee employee = new Employee();

        employee.setName("Jack");
        employee.setCity("USA");
        employee.setId(id);
        employee.setMobile("555-5525568");

        return employee;

    }
}
