package com.self.tutorials.service;


import com.self.tutorials.model.Employee;

public interface EmployeeService {

    void save (Employee employee);
    Employee getEmployee(Integer id);
}
