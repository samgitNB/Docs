import java.lang.reflect.Field;

public class Main {

    public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException {

        Other other = new Other("tharanga");
        Field field = Other.class.getDeclaredField("name");
        field.setAccessible(true);
        Object value = field.get(other);
        System.out.println(value);
    }
}

class Other {
    private String name;
    public Other(String name) {
        this.name = name;
    }
}
