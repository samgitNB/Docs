export class Player {
    
    id: number;
    firstName: string;
    lastName: string;
    country:string;
    type:string
    description: string;

    constructor() {

        this.firstName = "";
        this.lastName = "";
        this.description = "";
        this.country="";
        this.type="";
    }

    // setName(name:string):void{

    //     this.firstName = name;
    // }
    // getName():string{
    //     return this.firstName;
    // }
}