import { location } from 'ngx-bootstrap/utils/facade/browser';
import { Component, OnInit, Provider } from '@angular/core';
import { PlayerService } from './services/players/player.service';
import { Player } from './models/player';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ PlayerService ]
})

export class AppComponent implements OnInit {
title = 'rxjs angular 4';
players : Player;
jsonPlayer:Player = {id:3,firstName:'Zoya',lastName:'Fernado' ,type:'basketball',country:'SL',description:'basketball palyer'}

// player = [{id: '',name: '',location: '' }];

constructor(private _player:PlayerService) {}

ngOnInit() {

  //this.jsonPlayer = [{}];
  // this.getAllPlayers();
}


/**
 * service methods
 * GET , POST , DELETE , PATCH ...
 */

//GET
getAllPlayers(){
  this._player.getPlayers().subscribe(res => console.log(' GET Results :' ,res));
}
// POST

savePlayer(){
  this._player.insertPlayer(this.jsonPlayer).subscribe(res => console.log(' POST Results :' ,res));
}

removePlayer(){
  this._player.deletePlayer(this.jsonPlayer).subscribe(res => console.log(' POST Results :' ,res));
}

}//app-componet end

