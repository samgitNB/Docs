
import { Injectable } from '@angular/core';
import { Headers ,Http ,Response} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';  
import 'rxjs/add/operator/map';  
import 'rxjs/add/operator/catch';

@Injectable()
export class ArticleService {

  private url = "https://jsonplaceholder.typicode.com/users";
  private postUrl = "https://reqres.in/api/users";

  
  constructor(private http: Http) { 
    // console.log("Article Service Initilaized: ********");
  }

  
  getArticlesWithPromise(){
    return this.http.get(this.url).toPromise()
    .then(response => response.json())
    .catch(this.handdleError);
  }
  getArticlesWithObservable(){

    return this.http.get(this.url)
    .map(response => response.json())
    .catch(this.handdleErrorObs);
  }

  saveProfile(){

    return this.http.post(this.postUrl , {name:'sameera',job:'Java Devloper (SE)',city:'CMB'})
    .map((response : Response) => response.json())
    .catch(this.handdleErrorObs);

  }


  /**
   * 
   * error messages
   */

  private handdleError(error :any){
    console.log('[ ERROR ] : An Error occurred ' ,error);
    return Promise.reject(error.message || error);
  }

  private handdleErrorObs(response :Response) : Observable<any>{
    let errorMsg = `${response.status} - ${response.statusText}`;
    return Observable.throw(errorMsg );
  }
}
