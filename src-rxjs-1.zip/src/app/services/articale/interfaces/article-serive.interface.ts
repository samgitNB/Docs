
export interface IArticle {
    
    id:number;
    username:string;
    phone:string;
    email:string;
  }
  