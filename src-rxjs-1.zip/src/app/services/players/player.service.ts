
import { Player } from '../../models/player';

import { Injectable } from '@angular/core';
import { Http , Response , Headers} from '@angular/http';
import { Observable } from 'rxjs/Observable';
// import 'rxjs/add/operator/toPromise';  
import 'rxjs/add/operator/map';  
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';


@Injectable()
export class PlayerService {

  private baseURL = "http://localhost:3000";
  private  headers = new Headers();
  p:Player =new Player();


  constructor(private _http: Http) { 
    console.log('PLAYER_SERVICE'); 
    this.headers.append('Content-Type', 'application/json');
   // this.p.setName('sameera');
    //console.log(new Player().getName());
  }

  getPlayers(): Observable<any>{

    let baseGET = 'player';
  
  
    return this._http.get(`${this.baseURL}/${baseGET}`)
    .map((response:Response) => response.json() as Player[])
    .catch(this.handdleError);
  }

  insertPlayer(player : Player): Observable<any>{
    let basePOST = 'player';

    return this._http.post (`${this.baseURL}/${basePOST}` ,JSON.stringify(player) , { headers:this.headers} )
    .map((response:Response) => response.json() as Player[])
    .catch(this.handdleError);
  }

  deletePlayer(player : Player): Observable<any>{

    let baseDELETE = 'player/'+`${player.id}`;

    //console.log(baseDELETE);

    return this._http.delete(`${this.baseURL}/${baseDELETE}`)
    .map((response:Response) => response.json() as Player[])
    .catch(this.handdleError);
  }

  private handdleError(response :Response) : any{
    let errorMsg = `[  ${response.status} - ${response.statusText} ] `;
    return Observable.throw(errorMsg );
  }

}
